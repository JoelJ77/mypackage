#mypackage

how to install